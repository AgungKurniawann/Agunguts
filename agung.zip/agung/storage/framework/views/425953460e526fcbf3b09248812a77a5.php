<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman siswa</title>
</head>
<body>
<h1>halaman siswa</h1>
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('/profile')); ?>">profile</a></li>
    </ul>
</body>
</html><?php /**PATH D:\laravel_C1RIAN\resources\views/mahasiswa.blade.php ENDPATH**/ ?>